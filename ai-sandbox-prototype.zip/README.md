# AI-Driven Dynamic Sandbox Prototype

## Overview

This project is a prototype for an AI-driven sandbox that explores dynamic world building, interactive AI beings, 
and procedural creativity. The goal is to provide a solid starting point for experimentation and rapid prototyping 
in game development. 

Key features include:
- **Dynamic World Building:** AI entities adjust landscapes, lighting, and generate unique dreamscapes and mythologies.
- **Interactive AI Beings:** AI mentors and creatures that interact and evolve.
- **Procedural Creativity:** AI-generated music, art, and story elements.
- **Cutting-Edge Technology:** Uses GPU acceleration, physics simulation, and modern rendering.

## Dependencies

Ensure these libraries are installed:
- [LibTorch (PyTorch C++ API)](https://pytorch.org/)
- [faiss](https://github.com/facebookresearch/faiss)
- [nlohmann/json](https://github.com/nlohmann/json)
- [spdlog](https://github.com/gabime/spdlog)
- [OpenSSL](https://www.openssl.org/)
- [CUDA](https://developer.nvidia.com/cuda-zone)
- [Vulkan](https://www.vulkan.org/)
- [OptiX](https://developer.nvidia.com/optix)
- [PhysX](https://github.com/NVIDIAGameWorks/PhysX)

## Building the Project

1. **Extract the repository**

2. **Create a build directory and configure the project:**

   ```bash
   mkdir build
   cd build
   cmake ..
   ```

3. **Build the project:**

   ```bash
   cmake --build .
   ```

4. **Run the executable:**

   ```bash
   ./ai_sandbox_prototype
   ```

## Feedback

Looking for feedback, advice, and constructive criticism to improve this project. Suggestions welcome!

## License

This project is licensed under the MIT License.
